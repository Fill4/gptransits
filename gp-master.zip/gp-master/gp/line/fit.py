#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import division, print_function

__all__ = []

import emcee


def fit_mcmc(x, y, yerr, m0, b0, hyper0, kernel, lnlike):
    pass
